/**
 * Created by yejiansuo on 2016/8/4.
 */
var gui = require('nw.gui');
var path = require('path');
var regedit = require('regedit');
var updater = require('hupdater');
var pkg = require('./../package.json');
/**
 * 获取操作系统架构
 * @returns {*}
 */
function getCPU() {
    var agent = navigator.userAgent.toLowerCase();
    if(agent.indexOf("win64")>=0 || agent.indexOf("wow64")>=0) return "x64";
    return navigator.cpuClass;
}

/**
 * 通过注册表获取安装路径
 */
function getInstallPath(){
    var x86_key = 'HKLM\\Software\\HOne\\Install';
    var x64_key = 'HKLM\\SOFTWARE\\Wow6432Node\\HOne\\Install';
    var key = getCPU()=='x64'?x64_key:x86_key;
    regedit.list(key, function(err, result) {
        if(err){
           $('#getInstallPath').html('未安装程序');
           console.log(err);
           return;
        }
        var installPath = result[key]['values']['path'];
        $('#getInstallPath').html(installPath.value);
     });
}

/**
 * 检测更新
 */
function checkUpdate(){
    $('#checkUpdate').append('--开始检查新版本<br>');

    var serverUrl = pkg.updateServer; //更新服务地址
    var localVersion = pkg.version;  //本地版本号
    var targetPath =  path.dirname(process.execPath); //本地程序根目录

    var versionCheckApi = serverUrl + '/api/client/one/version';
    //开始检查版本号
    updater.checkVersion(versionCheckApi, function (err, newVersion) {
        if(err){
            console.log(err);
            $('#checkUpdate').append('--检查更新失败<br>');
            return;
        }
        //判断是否需要更新
        var ifUpdate = updater.ifNeedUpdate(localVersion, newVersion);
        if(ifUpdate){
            $('#checkUpdate').append('--发现新版本，开始下载新版本<br>');

            var downloadApi = serverUrl + '/api/client/one/version/'+newVersion+'.zip';
            //开始下载新版本包
            updater.downloadNewVersion(downloadApi, targetPath, function(err, filePath){
                if(err){
                    console.log(err);
                    $('#checkUpdate').append('--下载更新失败<br>');
                    return;
                }
                //下载完成后，开始解压缩更新包
                $('#checkUpdate').append('--下载完成，开始更新新版本<br>');
                updater.unpackNewVersion(filePath, function() {
                    $('#checkUpdate').append('--更新完成，5秒后将重启程序<br>');
                    updater.cleanOldVersion(filePath, function(err) {
                        
                    });
                    setTimeout(function () {
                        updater.restartApp(gui.App);
                    },5000);

                });
            });
        }else{
            $('#checkUpdate').append('--没有发现新版本<br>');
        }
    });
}